<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6687082b43f10             |
    |_______________________________________|
*/
 namespace Pmpr\Module\PWA\Interfaces; interface CommonInterface { const megoekiemouaquwk = "\x76\x31\56\x31\x2e\x31\62"; const kwckogkkioyqyqqq = "\57\x73\x77\x25\x73\x2d\x25\x73\x2e\x6a\163"; const jgkmawiysugewomi = "\155\x61\156\151\146\x65\163\164\x25\x73\55\45\x73\56\167\x65\x62\155\x61\156\x69\x66\x65\163\x74"; }
