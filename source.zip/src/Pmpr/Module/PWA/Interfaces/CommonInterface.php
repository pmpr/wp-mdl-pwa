<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e42338df72             |
    |_______________________________________|
*/
 namespace Pmpr\Module\PWA\Interfaces; interface CommonInterface { const megoekiemouaquwk = "\166\61\56\x31\56\61\62"; const kwckogkkioyqyqqq = "\x2f\x73\167\x25\163\x2d\x25\163\x2e\x6a\163"; const jgkmawiysugewomi = "\x6d\x61\x6e\x69\x66\x65\x73\x74\x25\163\x2d\x25\163\56\x77\x65\x62\155\141\156\x69\x66\x65\x73\164"; }
