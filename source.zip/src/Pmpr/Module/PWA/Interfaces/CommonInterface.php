<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665e31af9c01b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\PWA\Interfaces; interface CommonInterface { const megoekiemouaquwk = "\x76\61\x2e\x31\x2e\x31\x32"; const kwckogkkioyqyqqq = "\x2f\x73\x77\45\163\55\45\x73\x2e\152\163"; const jgkmawiysugewomi = "\155\141\x6e\151\x66\x65\x73\x74\45\163\55\45\x73\x2e\167\145\142\155\x61\156\151\146\145\x73\164"; }
