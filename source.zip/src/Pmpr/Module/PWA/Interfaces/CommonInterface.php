<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             660dc1bc02505             |
    |_______________________________________|
*/
 namespace Pmpr\Module\PWA\Interfaces; interface CommonInterface { const megoekiemouaquwk = "\166\61\x2e\61\x2e\x31\62"; const kwckogkkioyqyqqq = "\57\x73\167\x25\x73\x2d\x25\163\x2e\152\x73"; const jgkmawiysugewomi = "\x6d\x61\156\x69\146\x65\x73\164\45\163\x2d\45\163\x2e\167\x65\142\155\x61\156\151\146\x65\x73\164"; }
