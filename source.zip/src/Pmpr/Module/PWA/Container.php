<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6801065d11bdf             |
    |_______________________________________|
*/
 namespace Pmpr\Module\PWA; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\PWA\Traits\CommonTrait; abstract class Container extends BaseClass { use CommonTrait; }
