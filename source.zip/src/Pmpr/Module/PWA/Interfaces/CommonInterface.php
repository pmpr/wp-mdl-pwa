<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             660698819b965             |
    |_______________________________________|
*/
 namespace Pmpr\Module\PWA\Interfaces; interface CommonInterface { const megoekiemouaquwk = "\x76\61\56\x31\56\x31\x32"; const kwckogkkioyqyqqq = "\x2f\163\167\45\163\55\x25\x73\56\x6a\163"; const jgkmawiysugewomi = "\155\x61\x6e\x69\146\145\163\164\45\x73\55\x25\163\56\x77\145\142\x6d\x61\x6e\x69\146\x65\x73\164"; }
