<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a8a043545             |
    |_______________________________________|
*/
 namespace Pmpr\Module\PWA\Interfaces; interface CommonInterface { const megoekiemouaquwk = "\x76\61\x2e\x31\56\61\62"; const kwckogkkioyqyqqq = "\x2f\x73\x77\x25\x73\x2d\x25\x73\56\x6a\163"; const jgkmawiysugewomi = "\155\x61\x6e\x69\x66\145\x73\x74\x25\x73\x2d\x25\x73\x2e\167\145\142\155\x61\x6e\x69\x66\145\163\x74"; }
