<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66840101617f1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\PWA\Interfaces; interface CommonInterface { const megoekiemouaquwk = "\166\x31\x2e\x31\56\61\x32"; const kwckogkkioyqyqqq = "\x2f\x73\x77\x25\163\55\45\163\56\152\163"; const jgkmawiysugewomi = "\x6d\x61\156\x69\x66\x65\163\164\45\x73\x2d\x25\x73\x2e\x77\x65\x62\155\141\156\x69\x66\x65\163\164"; }
