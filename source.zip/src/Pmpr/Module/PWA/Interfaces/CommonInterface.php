<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66586039ea97a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\PWA\Interfaces; interface CommonInterface { const megoekiemouaquwk = "\x76\61\x2e\x31\x2e\61\62"; const kwckogkkioyqyqqq = "\x2f\x73\x77\45\x73\x2d\x25\163\x2e\x6a\x73"; const jgkmawiysugewomi = "\x6d\141\x6e\151\146\145\163\x74\45\x73\x2d\x25\163\x2e\x77\145\x62\155\x61\x6e\151\146\x65\x73\x74"; }
